<!-- Begin page content -->
<main role="main" class="flex-shrink-0">
  <div class="container">
    <h1 class="mt-5">UAS PEMPROGRAMAN INTERNET LANJUT</h1>
    <p class="lead">ANDRI MARSELINDO MONE.</p>
  </div>
</main>