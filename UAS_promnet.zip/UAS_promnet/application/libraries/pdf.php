<?php
class pdf {
	function__construct() {
		include_once APPPATH . '/third_party/pfdf/pfdf.php';
	}
}
?>